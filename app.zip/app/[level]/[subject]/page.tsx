
import { supabase } from "@/lib/supabase";
import { getOverallRating } from "@/lib/ratings";

export default async function SubjectPage({
  params,
}: {
  params: Promise<{
    level: string;
    subject: string;
  }>;
}) {
  const { level, subject } =
    await params;

  const { data: subjectFaculties, error } =
    await supabase
      .from("faculties")
      .select("*")
      .ilike("subject", subject)
      .ilike("level", level)
      .eq("active", true);

  if (error) {
    return (
      <main className="max-w-7xl mx-auto p-10">
        Error loading faculties.
      </main>
    );
  }

  const { data: allReviews } =
    await supabase
      .from("reviews")
      .select("*");

  return (
    <main className="min-h-screen bg-slate-100">

      {/* Hero */}

      <section className="bg-slate-900 text-white">

        <div className="max-w-7xl mx-auto px-6 py-20">

          <div className="max-w-4xl">

            <h1 className="text-5xl md:text-7xl font-extrabold">
              <span className="text-white-500">
                {subject.toUpperCase()}
              </span>
            </h1>

            <p className="mt-6 text-xl text-slate-300">
              Compare faculty reviews,
              ratings and student experiences.
            </p>

          </div>

        </div>

      </section>

      {/* Faculty Cards */}

      <section className="max-w-7xl mx-auto px-6 py-16">

        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

          {subjectFaculties?.map(
            (faculty) => {

              const facultyReviews =
                allReviews?.filter(
                  (review) =>
                    review.faculty_slug ===
                    faculty.slug
                ) ?? [];

              const overallRating =
                getOverallRating(
                  facultyReviews
                );

              const bestFor =
                facultyReviews[0]
                  ?.best_for?.[0] ??
                "No Reviews";

              const teachingStyle =
                facultyReviews[0]
                  ?.teacher_style ??
                "Unknown";

              const reviewPreview =
                facultyReviews[0]
                  ?.review_text ??
                "No reviews yet.";

              return (
                <a
                  key={faculty.slug}
                  href={`/faculty/${faculty.slug}`}
                  className="bg-white rounded-3xl border border-slate-200 shadow-lg hover:shadow-2xl hover:border-blue-300 transition-all p-8 block"
                >

                  <div className="flex justify-between items-start">

                    <div>

                      <h2 className="text-3xl font-bold text-slate-900">
                        {faculty.faculty_name}
                      </h2>

                      <div className="flex gap-2 mt-3 flex-wrap">

                        <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                          {teachingStyle}
                        </span>

                        <span className="bg-slate-100 text-slate-700 px-3 py-1 rounded-full text-sm font-medium">
                          {bestFor}
                        </span>

                      </div>

                    </div>

                    <div className="text-center">

                      <div className="text-5xl font-extrabold text-blue-600">
                        {overallRating}
                      </div>

                      <div className="text-xs text-slate-500 mt-1">
                        Rating
                      </div>

                    </div>

                  </div>

                  <div className="mt-4 text-slate-500 text-sm">
                    {facultyReviews.length} Reviews
                  </div>

                  <div className="mt-6 border-l-4 border-blue-500 pl-4">

                    <p className="text-slate-700 italic line-clamp-3">
                      "{reviewPreview}"
                    </p>

                  </div>

                  <div className="grid grid-cols-3 gap-3 mt-8">

                    <div className="bg-slate-50 rounded-xl p-4 text-center">

                      <div className="font-bold text-slate-900">
                        ₹{faculty.starting_price}
                      </div>

                      <div className="text-xs text-slate-500 mt-1">
                        Price
                      </div>

                    </div>

                    <div className="bg-slate-50 rounded-xl p-4 text-center">

                      <div className="font-bold text-slate-900">
                        {faculty.regular_hours}
                      </div>

                      <div className="text-xs text-slate-500 mt-1">
                        Hours
                      </div>

                    </div>

                    <div className="bg-slate-50 rounded-xl p-4 text-center">

                      <div className="font-bold text-slate-900">
                        {faculty.mode?.[0]}
                      </div>

                      <div className="text-xs text-slate-500 mt-1">
                        Mode
                      </div>

                    </div>

                  </div>

                  <div className="mt-8 text-blue-600 font-semibold">
                    View Profile →
                  </div>

                </a>
              );
            }
          )}

        </div>

      </section>

    </main>
  );
}

