
import { supabase } from "@/lib/supabase";

export default async function LevelPage({
  params,
}: {
  params: Promise<{ level: string }>;
}) {
  const { level } = await params;

  const { data: faculties, error } =
    await supabase
      .from("faculties")
      .select("subject")
      .eq("active", true)
      .ilike("level", level);

  if (error) {
    return (
      <main className="max-w-7xl mx-auto p-10">
        Error loading subjects.
      </main>
    );
  }

  const subjects = [
    ...new Set(
      faculties?.map(
        (faculty) => faculty.subject
      ) ?? []
    ),
  ];

  return (
    <main className="min-h-screen bg-slate-100">

      <section className="bg-slate-900 text-white">

        <div className="max-w-7xl mx-auto px-6 py-20">

          <div className="max-w-4xl">

            <h1 className="text-5xl md:text-7xl font-extrabold">
              CA{" "}
              <span className="text-blue-500">
                {level.toUpperCase()}
              </span>
            </h1>

            <p className="mt-6 text-xl text-slate-300">
              Browse subjects, compare faculties
              and find the right teacher for you.
            </p>

          </div>

        </div>

      </section>

      <section className="max-w-6xl mx-auto px-6 py-16">

        <div className="mb-10">

          <h2 className="text-4xl font-bold text-slate-900">
            Subjects
          </h2>

          <p className="mt-2 text-slate-600">
            Select a subject to view
            faculty reviews and ratings.
          </p>

        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

          {subjects.map((subject) => (
            <a
              key={subject}
              href={`/${level}/${subject.toLowerCase()}`}
              className="bg-white rounded-2xl p-8 border border-slate-200 shadow-lg hover:shadow-2xl hover:border-blue-300 transition-all"
            >

              <h3 className="text-3xl font-bold text-slate-900">
                {subject}
              </h3>

              <p className="mt-4 text-slate-600">
                Browse faculty reviews,
                ratings and comparisons.
              </p>

              <div className="mt-8 text-blue-600 font-semibold">
                Browse Faculties →
              </div>

            </a>
          ))}

        </div>

      </section>

    </main>
  );
}
