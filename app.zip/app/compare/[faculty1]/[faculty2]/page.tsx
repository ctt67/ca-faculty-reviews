import { supabase } from "@/lib/supabase";
import {
  getAverageMetric,
  getOverallRating,
} from "@/lib/ratings";

export default async function ComparePage({
  params,
}: {
  params: Promise<{
    faculty1: string;
    faculty2: string;
  }>;
}) {
  const {
    faculty1: faculty1Slug,
    faculty2: faculty2Slug,
  } = await params;

  const { data: faculty1 } = await supabase
    .from("faculties")
    .select("*")
    .eq("slug", faculty1Slug)
    .single();

  const { data: faculty2 } = await supabase
    .from("faculties")
    .select("*")
    .eq("slug", faculty2Slug)
    .single();

  if (!faculty1 || !faculty2) {
    return (
      <main className="max-w-4xl mx-auto p-10">
        <h1 className="text-3xl font-bold">
          Faculty not found
        </h1>
      </main>
    );
  }

  const { data: reviews1 } = await supabase
    .from("reviews")
    .select("*")
    .eq("faculty_slug", faculty1Slug);

  const { data: reviews2 } = await supabase
    .from("reviews")
    .select("*")
    .eq("faculty_slug", faculty2Slug);

  const faculty1Reviews = reviews1 ?? [];
  const faculty2Reviews = reviews2 ?? [];

  const faculty1Rating = getOverallRating(faculty1Reviews);
  const faculty2Rating = getOverallRating(faculty2Reviews);

  const facultyFields = Object.keys(faculty1).filter(
    (field) =>
      ![
        "id",
        "slug",
        "faculty_name",
        "subject",
        "level",
        "active",
        "website",
        "youtube",
        "created_at",
        "updated_at",
      ].includes(field)
  );

  const ratingFields = Object.keys(
    faculty1Reviews[0] ?? {}
  ).filter(
    (field) =>
      typeof faculty1Reviews[0]?.[field] === "number" &&
      !["id", "faculty_id"].includes(field)
  );

  const formatFieldName = (field: string) =>
    field
      .replaceAll("_", " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());

  return (
    <main className="min-h-screen bg-slate-100">

      <section className="bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-6 py-20">
          <h1 className="text-5xl md:text-7xl font-extrabold">
            Compare
            <span className="text-blue-500"> Faculties</span>
          </h1>
          <p className="mt-6 text-xl text-slate-300">
            Compare ratings, pricing and student experiences side-by-side.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">

        {/* Overall Rating Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">

          <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8">
            <h2 className="text-3xl font-bold text-slate-900">{faculty1.faculty_name}</h2>
            <p className="text-slate-500 mt-2">{faculty1.subject}</p>
            <div className="mt-6">
              <div className="text-5xl font-extrabold text-blue-600">{faculty1Rating}</div>
              <div className="text-sm text-slate-500 mt-1">Overall Rating</div>
            </div>
            {faculty1Rating > faculty2Rating && (
              <div className="mt-4 inline-flex bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                Best Rated
              </div>
            )}
            <p className="text-slate-500 mt-4">{faculty1Reviews.length} Reviews</p>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8">
            <h2 className="text-3xl font-bold text-slate-900">{faculty2.faculty_name}</h2>
            <p className="text-slate-500 mt-2">{faculty2.subject}</p>
            <div className="mt-6">
              <div className="text-5xl font-extrabold text-blue-600">{faculty2Rating}</div>
              <div className="text-sm text-slate-500 mt-1">Overall Rating</div>
            </div>
            {faculty2Rating > faculty1Rating && (
              <div className="mt-4 inline-flex bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                Best Rated
              </div>
            )}
            <p className="text-slate-500 mt-4">{faculty2Reviews.length} Reviews</p>
          </div>

        </div>

        {/* Faculty Details Table */}
        <div className="mb-10">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Faculty Details</h2>
          <div className="grid grid-cols-3 bg-white text-slate-900 rounded-3xl border border-slate-200 shadow-lg overflow-hidden">

            <div className="font-semibold p-5 bg-slate-50 border-b text-slate-900">Metric</div>
            <div className="font-semibold p-5 bg-slate-50 border-b text-center text-slate-900">{faculty1.faculty_name}</div>
            <div className="font-semibold p-5 bg-slate-50 border-b text-center text-slate-900">{faculty2.faculty_name}</div>

            {facultyFields.map((field) => (
              <div key={field} className="contents">
                <div className="p-4 border-b text-slate-900">{formatFieldName(field)}</div>
                <div className="p-4 border-b text-center text-slate-900">
                  {Array.isArray(faculty1[field])
                    ? faculty1[field].join(", ")
                    : String(faculty1[field] ?? "-")}
                </div>
                <div className="p-4 border-b text-center text-slate-900">
                  {Array.isArray(faculty2[field])
                    ? faculty2[field].join(", ")
                    : String(faculty2[field] ?? "-")}
                </div>
              </div>
            ))}

          </div>
        </div>

        {/* Ratings Comparison Table */}
        <div className="mb-10">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Ratings Comparison</h2>
          <div className="grid grid-cols-3 bg-white text-slate-900 rounded-3xl border border-slate-200 shadow-lg overflow-hidden">

            <div className="font-semibold p-5 bg-slate-50 border-b text-slate-900">Metric</div>
            <div className="font-semibold p-5 bg-slate-50 border-b text-center text-slate-900">{faculty1.faculty_name}</div>
            <div className="font-semibold p-5 bg-slate-50 border-b text-center text-slate-900">{faculty2.faculty_name}</div>

            {ratingFields.map((field) => (
              <div key={field} className="contents">
                <div className="p-4 border-b text-slate-900">{formatFieldName(field)}</div>
                <div className="p-4 border-b text-center text-slate-900">
                  {getAverageMetric(faculty1Reviews, field)}
                </div>
                <div className="p-4 border-b text-center text-slate-900">
                  {getAverageMetric(faculty2Reviews, field)}
                </div>
              </div>
            ))}

          </div>
        </div>

        {/* Student Reviews */}
        <div className="mt-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">What Students Are Saying</h2>
          <div className="grid md:grid-cols-2 gap-6">

            <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8">
              <h3 className="text-2xl font-bold mb-6">{faculty1.faculty_name}</h3>
              {faculty1Reviews.map((review) => (
                <div key={review.id} className="border-b border-slate-200 pb-6 mb-6 last:border-0">
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="bg-blue-50 text-blue-700 rounded-full px-3 py-1 text-sm font-medium">{review.teacher_style}</span>
                    <span className="bg-slate-100 text-slate-700 rounded-full px-3 py-1 text-sm font-medium">{review.student_type}</span>
                    <span className="bg-slate-100 text-slate-700 rounded-full px-3 py-1 text-sm font-medium">{review.attempt}</span>
                  </div>
                  <p className="mb-2"><strong>Best For:</strong> {review.best_for?.join(", ")}</p>
                  <p className="mb-2"><strong>Pros:</strong> {review.pros}</p>
                  <p className="mb-2"><strong>Cons:</strong> {review.cons}</p>
                  <p className="text-slate-700">{review.review_text}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8">
              <h3 className="text-2xl font-bold mb-6">{faculty2.faculty_name}</h3>
              {faculty2Reviews.map((review) => (
                <div key={review.id} className="border-b border-slate-200 pb-6 mb-6 last:border-0">
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="bg-blue-50 text-blue-700 rounded-full px-3 py-1 text-sm font-medium">{review.teacher_style}</span>
                    <span className="bg-slate-100 text-slate-700 rounded-full px-3 py-1 text-sm font-medium">{review.student_type}</span>
                    <span className="bg-slate-100 text-slate-700 rounded-full px-3 py-1 text-sm font-medium">{review.attempt}</span>
                  </div>
                  <p className="mb-2"><strong>Best For:</strong> {review.best_for?.join(", ")}</p>
                  <p className="mb-2"><strong>Pros:</strong> {review.pros}</p>
                  <p className="mb-2"><strong>Cons:</strong> {review.cons}</p>
                  <p className="text-slate-700">{review.review_text}</p>
                </div>
              ))}
            </div>

          </div>
        </div>

      </section>
    </main>
  );
}