
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function ComparePage() {
  const router = useRouter();

  const [faculties, setFaculties] =
    useState<any[]>([]);

  const [level, setLevel] =
    useState("");

  const [subject, setSubject] =
    useState("");

  const [faculty1, setFaculty1] =
    useState("");

  const [faculty2, setFaculty2] =
    useState("");

  useEffect(() => {
    const loadFaculties = async () => {
      const { data } = await supabase
        .from("faculties")
        .select("*")
        .eq("active", true);

      setFaculties(data ?? []);
    };

    loadFaculties();
  }, []);

  const levels = [
    ...new Set(
      faculties.map(
        (faculty) => faculty.level
      )
    ),
  ];

  const subjects = [
    ...new Set(
      faculties
        .filter(
          (faculty) =>
            faculty.level === level
        )
        .map(
          (faculty) => faculty.subject
        )
    ),
  ];

  const filteredFaculties =
    faculties.filter(
      (faculty) =>
        faculty.level === level &&
        faculty.subject === subject
    );

  const handleCompare = () => {
    if (!faculty1 || !faculty2) {
      alert(
        "Please select both faculties"
      );
      return;
    }

    if (faculty1 === faculty2) {
      alert(
        "Please select different faculties"
      );
      return;
    }

    router.push(
      `/compare/${faculty1}/${faculty2}`
    );
  };

  return (
    <main className="min-h-screen bg-slate-100">

      <section className="bg-slate-900 text-white">

        <div className="max-w-7xl mx-auto px-6 py-20">

          <div className="max-w-4xl">

            <h1 className="text-5xl md:text-7xl font-extrabold">
              Compare
              <span className="text-blue-500">
                {" "}Faculties
              </span>
            </h1>

            <p className="mt-6 text-xl text-slate-300">
              Compare two faculties side-by-side
              before making your decision.
            </p>

          </div>

        </div>

      </section>

      <section className="max-w-3xl mx-auto px-6 py-16">

        <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8">

          <div className="space-y-6">

            <div>

              <label className="block mb-2 font-medium text-slate-700">
                Level
              </label>

              <select
                value={level}
                onChange={(e) => {
                  setLevel(
                    e.target.value
                  );
                  setSubject("");
                  setFaculty1("");
                  setFaculty2("");
                }}
                className="w-full border border-slate-300 rounded-xl p-4 text-slate-900 bg-white"
              >
                <option
                  value=""
                  className="text-slate-900"
                >
                  Select Level
                </option>

                {levels.map((level) => (
                  <option
                    key={level}
                    value={level}
                    className="text-slate-900"
                  >
                    {level}
                  </option>
                ))}

              </select>

            </div>

            {level && (
              <div>

                <label className="block mb-2 font-medium text-slate-700">
                  Subject
                </label>

                <select
                  value={subject}
                  onChange={(e) => {
                    setSubject(
                      e.target.value
                    );
                    setFaculty1("");
                    setFaculty2("");
                  }}
                  className="w-full border border-slate-300 rounded-xl p-4 text-slate-900 bg-white"
                >

                  <option
                    value=""
                    className="text-slate-900"
                  >
                    Select Subject
                  </option>

                  {subjects.map(
                    (subject) => (
                      <option
                        key={subject}
                        value={subject}
                        className="text-slate-900"
                      >
                        {subject}
                      </option>
                    )
                  )}

                </select>

              </div>
            )}

            {subject && (
              <>
                <div>

                  <label className="block mb-2 font-medium text-slate-700">
                    Faculty 1
                  </label>

                  <select
                    value={faculty1}
                    onChange={(e) =>
                      setFaculty1(
                        e.target.value
                      )
                    }
                    className="w-full border border-slate-300 rounded-xl p-4 text-slate-900 bg-white"
                  >

                    <option
                      value=""
                      className="text-slate-900"
                    >
                      Select Faculty
                    </option>

                    {filteredFaculties.map(
                      (faculty) => (
                        <option
                          key={
                            faculty.slug
                          }
                          value={
                            faculty.slug
                          }
                          className="text-slate-900"
                        >
                          {
                            faculty.faculty_name
                          }
                        </option>
                      )
                    )}

                  </select>

                </div>

                <div>

                  <label className="block mb-2 font-medium text-slate-700">
                    Faculty 2
                  </label>

                  <select
                    value={faculty2}
                    onChange={(e) =>
                      setFaculty2(
                        e.target.value
                      )
                    }
                    className="w-full border border-slate-300 rounded-xl p-4 text-slate-900 bg-white"
                  >

                    <option
                      value=""
                      className="text-slate-900"
                    >
                      Select Faculty
                    </option>

                    {filteredFaculties.map(
                      (faculty) => (
                        <option
                          key={
                            faculty.slug
                          }
                          value={
                            faculty.slug
                          }
                          className="text-slate-900"
                        >
                          {
                            faculty.faculty_name
                          }
                        </option>
                      )
                    )}

                  </select>

                </div>
              </>
            )}

            <button
              onClick={handleCompare}
              className="w-full bg-blue-600 text-white py-4 rounded-xl font-semibold hover:bg-blue-700 transition"
            >
              Compare Faculties
            </button>

          </div>

        </div>

      </section>

    </main>
  );
}
