
export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-100">

      {/* Hero */}

      <section className="bg-slate-900 text-white">

        <div className="max-w-7xl mx-auto px-6 py-24">

          <div className="max-w-4xl">

            <div className="inline-flex rounded-full bg-slate-800 px-4 py-2 text-sm text-slate-300">
              For CA Students by CA Students
            </div>

            <h1 className="mt-6 text-5xl md:text-7xl font-extrabold leading-tight text-white">
              Find the Best
              <span className="text-blue-500">
                {" "}CA Faculty
              </span>
            </h1>

            <p className="mt-6 text-xl text-slate-300 max-w-3xl">
              Compare reviews, ratings, pricing,
              teaching styles and student experiences
              across CA Final, Intermediate and Foundation.
            </p>

            <div className="flex flex-wrap gap-4 mt-10">

              <a
                href="/compare"
                className="bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition"
              >
                Compare Faculties
              </a>

              <a
                href="/final"
                className="border border-slate-700 px-8 py-4 rounded-xl font-semibold hover:bg-slate-800 transition"
              >
                Browse Reviews
              </a>

            </div>

          </div>

        </div>

      </section>

      {/* Levels */}

      <section className="max-w-6xl mx-auto px-6 py-20">

        <div className="mb-12">

          <h2 className="text-4xl font-bold text-slate-900">
            Browse by Level
          </h2>

          <p className="text-slate-600 mt-2">
            Choose your CA level and explore faculty reviews.
          </p>

        </div>

        <div className="grid md:grid-cols-3 gap-6">

          <a
            href="/final"
            className="bg-white rounded-2xl p-8 border border-slate-200 shadow-lg hover:shadow-2xl hover:border-blue-300 transition-all"
          >

            <h3 className="text-3xl font-bold text-slate-900">
              CA Final
            </h3>

            <p className="mt-4 text-slate-600">
              For CA Final Students
            </p>

            <div className="mt-8 text-blue-600 font-semibold">
              Browse Faculties →
            </div>

          </a>

          <a
            href="/inter"
            className="bg-white rounded-2xl p-8 border border-slate-200 shadow-lg hover:shadow-2xl hover:border-blue-300 transition-all"
          >

            <h3 className="text-3xl font-bold text-slate-900">
              CA Intermediate
            </h3>

            <p className="mt-4 text-slate-600">
              For CA Intermediate Students
            </p>

            <div className="mt-8 text-blue-600 font-semibold">
              Browse Faculties →
            </div>

          </a>

          <a
            href="/foundation"
            className="bg-white rounded-2xl p-8 border border-slate-200 shadow-lg hover:shadow-2xl hover:border-blue-300 transition-all"
          >

            <h3 className="text-3xl font-bold text-slate-900">
              CA Foundation
            </h3>

            <p className="mt-4 text-slate-600">
              For CA Final Students
            </p>

            <div className="mt-8 text-blue-600 font-semibold">
              Browse Faculties →
            </div>

          </a>

        </div>

      </section>

      {/* CTA */}

      <section className="max-w-7xl mx-auto px-6 pb-20">

        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-12 text-center text-white shadow-2xl">

          <h2 className="text-4xl font-bold">
            Can't Decide Between Two Faculties?
          </h2>

          <p className="mt-4 text-blue-100 text-lg">
            Compare ratings, reviews, pricing and student experiences side-by-side.
          </p>

          <a
            href="/compare"
            className="inline-block mt-8 bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-slate-100 transition"
          >
            Start Comparing
          </a>

        </div>

      </section>

    </main>
  );
}

